smart waste managment system developed by achraf oudamane 

